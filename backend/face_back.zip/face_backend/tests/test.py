import  requests,pprint
import datetime

payload = {
    'username': 'huatsing',
    'password': '000421'
}


response = requests.post("http://192.168.126.130/api/mgr/signin",
                             data=payload)
pprint.pprint(response.json())

sessionid = response.cookies['sessionid']
start_datetime = datetime.datetime(2020, 4, 6, 21, 21, 20)

end_datetime = datetime.datetime(2021, 4, 10, 21, 21, 20)

string = str(start_datetime)+'#'+str(end_datetime)
payload = {
    'action': 'list_event',
    'pagenum': 1,
    'pagesize' : 2,
    'keywords':string
}


response = requests.get('http://192.168.126.130/api/mgr/event', params=payload,cookies={'sessionid': sessionid})

pprint.pprint(response.json())